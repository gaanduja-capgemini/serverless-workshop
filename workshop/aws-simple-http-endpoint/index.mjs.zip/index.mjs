export const handler = async (event, context) => {
  const name = event.queryStringParameters?.name || "world";
  console.log("EVENT: \n" + JSON.stringify(event, null, 2));
  const response = {
    statusCode: 200,
    body: JSON.stringify({
      message: `Hello ${name}`,
    }),
  };

  return response;
};
